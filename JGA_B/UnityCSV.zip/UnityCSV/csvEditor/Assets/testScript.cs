﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
using System.IO;

public class testScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
        StreamWriter sw = new StreamWriter(@"GameStage.csv", false, Encoding.GetEncoding("Shift_JIS"));
        string[] s1 = { "Name", "Scale.x", "Scale.y", "Scale.z", "Rot.x", "Rot.y", "Rot.z", "Pos.x", "Pos.y", "Pos.z", "NowDis"};
        string s2 = string.Join(",", s1);
        sw.WriteLine(s2);

        //地面
        Vector3 tileScale = GameObject.Find("Ground").transform.localScale;
        Vector3 tileRot = GameObject.Find("Ground").transform.rotation.eulerAngles;
        Vector3 tilePos = GameObject.Find("Ground").transform.position;
        string[] PlateStr = {"TilingPlate", "" + tileScale.x, "" + tileScale.z, "" + 1.0f,
            "XM_PIDIV2", "" + tileRot.y, "" + tileRot.z,
            "" + tilePos.x, "" + tilePos.y, "" + tilePos.z };
        string PlateStr2 = string.Join(",", PlateStr);
        sw.WriteLine(PlateStr2);

        //プレイヤー
        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        foreach(GameObject cube in players)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;

            string[] Str = {"Player",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }

        //敵
        GameObject[] normals = GameObject.FindGameObjectsWithTag("Normal");
        foreach(GameObject cube in normals)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;

            string[] Str = {"EnemyObject",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }

        GameObject[] midBosses = GameObject.FindGameObjectsWithTag("MidBoss");
        foreach(GameObject cube in midBosses)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;

            string[] Str = {"MidBossObject",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }

        GameObject[] Bosses = GameObject.FindGameObjectsWithTag("Boss");
        foreach(GameObject cube in Bosses)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;

            string[] Str = {"BossObject",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }

        GameObject[] LongDises = GameObject.FindGameObjectsWithTag("LongDisEnemy");
        foreach(GameObject cube in LongDises)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;

            string[] Str = {"LongDisEnemyObject",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }

        //ブロック
        GameObject[] blocks = GameObject.FindGameObjectsWithTag("Block");
        foreach(GameObject cube in blocks)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;

            string[] Str = {"FixedBox",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }
        //スポーンブロック
        GameObject[] SpawnBlocks = GameObject.FindGameObjectsWithTag("SpawnBlock");
        foreach (GameObject cube in SpawnBlocks)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;
            string District = cube.GetComponent<MyDistrict>().NowDistrict;
            string[] Str = {"SpawnBlock",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,""+District,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }

        //プラント
        GameObject[] Plant = GameObject.FindGameObjectsWithTag("Plant");
        foreach (GameObject cube in Plant)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;
            string District = cube.GetComponent<MyDistrict>().NowDistrict;
            string[] Str = {"Plant",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,""+District,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }
        //カメラターゲット
        GameObject[] Target = GameObject.FindGameObjectsWithTag("CameraTarget");
        foreach (GameObject cube in Target)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;
            string[] Str = {"TargetStart",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,""};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }
        //緑化の限界値
        GameObject[] CircleMaxScale = GameObject.FindGameObjectsWithTag("PlantMaxSize");
        foreach (GameObject cube in CircleMaxScale)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;
            string District = cube.GetComponent<MyDistrict>().NowDistrict;
            string[] Str = {"GreenCircleMaxSize",""+tmpScale.x * 10.0f, "" + tmpScale.y, "" + tmpScale.z * 10.0f,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,""+District,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }

        //ゲート
        GameObject[] Fence = GameObject.FindGameObjectsWithTag("Gate");
        foreach (GameObject cube in Fence)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;
            string District = cube.GetComponent<MyDistrict>().NowDistrict;
            string[] Str = {"Fence",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,""+District,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }

        //エリアチェッカー
        GameObject[] Area = GameObject.FindGameObjectsWithTag("AreaChecker");
        foreach (GameObject cube in Area)
        {
            Vector3 tmpScale = cube.transform.localScale;
            Vector3 tmpRot = cube.transform.rotation.eulerAngles;
            Vector3 tmpPos = cube.transform.position;
            string District = cube.GetComponent<MyDistrict>().NowDistrict;
            string[] Str = {"AreaChecker",""+tmpScale.x, "" + tmpScale.y, "" + tmpScale.z,
                "" + tmpRot.x, "" + tmpRot.y, "" + tmpRot.z,
                "" + tmpPos.x, "" + tmpPos.y, "" + tmpPos.z,""+District,};
            string Str2 = string.Join(",", Str);
            sw.WriteLine(Str2);
        }
        sw.Close();
    }

    // Update is called once per frame
    void Update () {
		
	}
}
